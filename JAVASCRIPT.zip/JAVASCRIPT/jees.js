//var angka, m;
//angka="1000000000";
//document.write(angka*angka);

/*var x = 10;
var y = 17;

x+= 20;
x++;
X-=y;

document.write(x);*/

/*var jam=15;
if(jam <= 12)
{
    document.write
    ("PAGI");
}

else if(jam > 12 && jam <= 15)
{
    document.write
    ("WAKTUNYA MBURJO");
}

else
{
    document.write
    ("GABUT");
}*/

/*var jam=15;
var pesan ="";

pesan =(jam <= 10)?
"SELAMAT PAGI" : "SELAMAT SIANG";

document.write(pesan);*/

/*var m=0;
for(m=0;m<=100;m++)
{
    if(m%2==0)
    document.write("Nomor :" +m);
    doc*/


//POPUP BOX - ALERT
    /*var jam = 17;
    if(jam <= 10)
    {
        alert("Selamat Pagi");
    }

    else if(jam > 10 && jam <= 15)
    {
        alert("Selamat Siang");
    }

    else
    {
        alert("Selamat Sore");
    }*/

/*var konfirmasi = confirm("Apakah Anda ingin membuka halaman ini?");
if(konfirmasi==true)
{
    document.location.href="halaman1.html";
}
else
{
    document.location.href="home.html";
}*/

var bil1,bil2,jml;
alert("Penjumlahan 2 Bilangan ");

bil1= +prompt("input Bilangan 1 ");
bil2= +prompt("input Bilangan 2");
jml= bil1+bil2;

var konfirmasi=confirm("Apakah Anda Ingin Langsung Melanjutkan?");
if(konfirmasi==true)
{
    document.write("Hasilnya = "+jml);
}
else
{
    document.location.href="index.html";
}
